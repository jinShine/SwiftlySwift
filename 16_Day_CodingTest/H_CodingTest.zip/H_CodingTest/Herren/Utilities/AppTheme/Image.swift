//
//  Image.swift
//  Herren
//
//  Created by Buzz.Kim on 2020/10/20.
//  Copyright © 2020 jinnify. All rights reserved.
//

import Foundation
import UIKit

struct Image {

  var btnLineUp: UIImage? {
    return UIImage(named: "btnLineUp")
  }
  
  var emptyProfile: UIImage? {
    return UIImage(named: "emptyProfile")
  }
  
}
